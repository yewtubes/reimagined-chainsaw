# PEKŌRA EXPOSED — landing page

Open `index.html` or `pekora-exposed-landing.html` directly in a browser. Both are identical, self-contained HTML files with embedded styling, fonts, images, and video. The original carrot background, branding, responsive cards, and muted looping video remain.

The page-by-page index covers all 12 sections present in the Ruins source (pages 1–3 and 5–13; page 4 is absent). Nine source screenshots are included from pages 2, 5, 6, 12 and 13, alongside the existing age screenshots. Captions describe visible content without treating source commentary as independently verified.

The entire redaction section and its 11 screenshot derivatives have been removed from the page and ZIP. Screenshots from pages 7–11 are omitted. The supplied style-reference chatlog is not bundled.

Screenshot cards use compact full-width rows, with images beside captions on wide screens. Intrinsic image dimensions reserve the correct space before loading.

`source-images.json` records image provenance and checksums. `source-coverage.json` records section coverage. `original/` retains the public client assets from the uploaded archive.

Optional local serving: `python3 serve.py`, then visit http://127.0.0.1:8080.
