#!/usr/bin/env python3
"""Local-only archive replay. Never forwards requests to the live service."""
import argparse
import hashlib
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import json
import mimetypes
from pathlib import Path
from urllib.parse import urlsplit

ROOT=Path(__file__).resolve().parent

def load_records():
    return {r['url']:r for r in json.loads((ROOT/'manifest.json').read_text())['records'] if r.get('path') and 200 <= r['status'] < 300}

class Replay(BaseHTTPRequestHandler):
    def do_GET(self):
        p=urlsplit(self.path)
        if p.path in ('/', '/index.html', '/pekora-exposed-landing.html'):
            return self.send_bytes((ROOT/'pekora-exposed-landing.html').read_bytes(),'text/html; charset=utf-8')
        if p.path in ('/', '/index.html', '/pekora-exposed-landing.html'):
            return self.send_bytes((ROOT/'pekora-exposed-landing.html').read_bytes(),'text/html; charset=utf-8')
        if p.path=='/capture-status.json':
            return self.send_bytes(json.dumps({'mode':'offline archive','files':len(self.server.records),'live_backend':False}).encode(),'application/json')
        if self.server.exposed and p.path=='/img/pekora-banner.png':
            return self.send_bytes((ROOT/'assets'/'pekora-exposed.png').read_bytes(),'image/png')
        if p.path.startswith('/__external/'):
            remote='https://'+self.path[len('/__external/'):]
        else:
            remote='https://pekora.pro'+self.path
        rec=self.server.records.get(remote)
        if not rec and not p.query:
            rec=self.server.records.get(remote.rstrip('/'))
        # Root-relative references sometimes add harmless cache-busting parameters.
        if not rec and p.query and p.path.startswith(('/_next/','/img/','/fonts/','/js/','/css/','/images/')):
            rec=self.server.records.get('https://pekora.pro'+p.path)
        if not rec:
            if any(p.path.startswith(x) for x in ['/api/','/apis/','/auth/','/v1/','/v2/']):
                return self.send_bytes(b'{"errors":[{"code":503,"message":"This capture has no account or game backend."}]}','application/json',503)
            return self.send_bytes(b'Resource was not captured. See manifest.json.','text/plain',404)
        data=(ROOT/rec['path']).read_bytes()
        content_type=rec.get('content_type') or mimetypes.guess_type(rec['path'])[0] or 'application/octet-stream'
        if any(x in content_type for x in ('html','javascript','css','json','text')):
            text=data.decode('utf-8',errors='replace')
            # Localize fonts and absolute Pekora links in the replay response only.
            # Archived source bytes remain unchanged on disk.
            for host in ('fonts.googleapis.com','fonts.gstatic.com'):
                text=text.replace('https://'+host,'/__external/'+host)
            text=text.replace('https://pekora.pro','').replace('http://pekora.pro','')
            data=text.encode()
        return self.send_bytes(data,content_type)

    def do_HEAD(self):
        self.send_response(405); self.end_headers()

    def do_POST(self):
        self.send_bytes(b'{"error":"Offline capture: submissions are disabled."}','application/json',503)
    do_PUT=do_POST
    do_PATCH=do_POST
    do_DELETE=do_POST

    def send_bytes(self,data,content_type,status=200):
        self.send_response(status)
        self.send_header('Content-Type',content_type)
        self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store')
        # Keep replay isolated: no credentials, forms, OAuth, API or analytics calls leave localhost.
        self.send_header('Content-Security-Policy',"default-src 'self' data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval' blob:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; form-action 'none'; frame-src 'none'; object-src 'none'; base-uri 'self'")
        self.send_header('X-Content-Type-Options','nosniff')
        self.end_headers(); self.wfile.write(data)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',type=int,default=8080)
    parser.add_argument('--exposed',action='store_true',help='Use the generated PEKORA EXPOSED wordmark')
    args=parser.parse_args()
    server=ThreadingHTTPServer(('127.0.0.1',args.port),Replay)
    server.records=load_records();server.exposed=args.exposed
    print(f'Archive replay: http://127.0.0.1:{args.port} (no live backend)',flush=True)
    server.serve_forever()
